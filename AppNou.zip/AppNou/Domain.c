#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include "Domain.h"



Participant* create(char* nume, char* prenume, int* scoruri)
{
	Participant* p = malloc(sizeof(Participant));
	p->nume = (char*)malloc((strlen(nume) + 1) * sizeof(char));
	p->prenume = (char*)malloc((strlen(prenume) + 1) * sizeof(char));
	p->scoruri = (int*)malloc(10 * sizeof(int));

	strcpy(p->nume, nume);
	strcpy(p->prenume, prenume);
	for (int i = 0; i < 10; i++)
	{
		p->scoruri[i] = scoruri[i];
	}
	return p;
}

char* get_nume(Participant* p)
{
	return p->nume;
}

char* get_prenume(Participant* p)
{
	return p->prenume;
}

int* get_scoruri(Participant* p)
{
	return p->scoruri;
}

int get_scor_mediu(Participant* p)
{
	int s = 0;
	for (int i = 0; i < 10; i++)
	{
		s += p->scoruri[i];
	}
	return s / 10;
}

void set_nume(Participant* p, char* nume)
{
	/*
	char* np;
	np = (char*)realloc(p->nume, (strlen(nume) + 1) * sizeof(char));
	if (np != NULL)
	{
		p->nume = np;
		strcpy(p->nume, nume);
	}
	else
		return 1;*/
	free(p->nume);
	p->nume = (char*)malloc((strlen(nume) + 1) * sizeof(char));
	strcpy(p->nume, nume);
}

void set_prenume(Participant* p, char* prenume)
{
	free(p->prenume);
	p->prenume = (char*)malloc((strlen(prenume) + 1) * sizeof(char));
	strcpy(p->prenume, prenume);
}

void set_scor(Participant* p, int poz, int scor)
{
	p->scoruri[poz - 1] = scor;
}

void set_scoruri(Participant* p, int* scoruri_noi)
{

	for (int i = 0; i < 10; i++)
	{
		p->scoruri[i] = scoruri_noi[i];
	}
}

int egale(Participant* p1, Participant* p2)
{
	if ((strcmp(p1->nume, p2->nume) == 0) && (strcmp(p1->prenume, p2->prenume) == 0))
		return 1;
	return 0;
}

void destroy_p(Participant* p)
{
	free(p->nume);
	free(p->prenume);
	free(p->scoruri);
	p->nume = NULL;
	p->nume = NULL;
	p->scoruri = NULL;
	free(p);
}

Participant* copy_participant(Participant* p)
{
	return create(p->nume, p->prenume, p->scoruri);
}