#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "Main.h"

Service init_serv()
{
	Service serv;
	serv.repo = init_repo();
	return serv;
}

void destroy_serv(Service* serv)
{
	destroy_repo(&serv->repo);
}

Participant* aux;

int add_serv(Service* serv, char* nume, char* prenume, int scoruri[], Lista* undo)
{

	if (valid_participant(nume, prenume, scoruri) == 0)
	{
		Participant* p = create(nume, prenume, scoruri);
		int ok = add_repo(&serv->repo, p, undo);
		if (ok == 0)
			destroy_p(p);
		return ok;
	}
	return valid_participant(nume, prenume, scoruri);
}

int delete_serv(Service* serv, char* nume, char* prenume, Lista* undo)
{
	int scoruri[10] = { 0 };
	Participant* p = create(nume, prenume, scoruri);
	int ok = delete_repo(&serv->repo, p, undo);
	destroy_p(p);
	return ok;
}

int search_serv(Service* serv, char* nume, char* prenume)
{
	int s[10] = { 0 };
	Participant* p = create(nume, prenume, s);
	int ok = search_repo(&serv->repo, p);
	destroy_p(p);
	return ok;
}

int update_all_serv(Service* serv, char* nume, char* prenume, char* nume_nou, char* prenume_nou, int scoruri[], Lista* undo)
{
	int s[10] = { 0 };
	Participant* p_vechi = create(nume, prenume, s);
	Participant* p_nou = create(nume_nou, prenume_nou, scoruri);
	int ok = update_repo(&serv->repo, p_vechi, p_nou, undo);
	destroy_p(p_vechi);
	destroy_p(p_nou);
	return ok;
}


void update_scor_serv(Service* serv, char* nume, char* prenume, int poz, int scor)
{
	int i = search_serv(serv, nume, prenume);
	Participant* p = get_participant(serv, i);
	set_scor(p, poz, scor);
	//destroy_p(&p);
}

Lista* get_participanti(Service* serv)
{
	return serv->repo.elems;
}

int get_nr_participanti(Service* serv)
{
	return get_dim(&serv->repo);
}

Participant* get_participant(Service* serv, int poz)
{
	return get_parti(&serv->repo, poz);
}

Lista* filtrare1(Service* serv, int scor)
{
	Lista* p_filtrat = create_empty();
	for (int i = 0; i < get_dim(&serv->repo); i++)
	{
		if (get_scor_mediu(get_participant(serv, i)) <= scor)
		{
			Participant* p = get_participant(serv, i);
			add(p_filtrat, create(p->nume, p->prenume, p->scoruri));
		}
	}
	return p_filtrat;
}

Lista* filtrare2(Service* serv, char c)
{
	Lista* p_filtrat = create_empty();
	for (int i = 0; i < get_dim(&serv->repo); i++)
	{
		char nume[30], cp;
		cp = c;
		strcpy(nume, get_nume(get_participant(serv, i)));
		if (tolower(nume[0]) == tolower(cp))
		{
			Participant* p = get_participant(serv, i);
			add(p_filtrat, create(p->nume, p->prenume, p->scoruri));
		}
	}
	return p_filtrat;
}


Lista* filtrareNoua(Service* serv, char c)
{
	Lista* par_filtrat = create_empty();
	for (int i = 0; i < get_dim(&serv->repo); i++)
	{
		char nume[30], cp;
		cp = c;
		strcpy(nume, get_prenume(get_participant(serv, i)));
		if (tolower(nume[0]) == tolower(cp))
		{
			Participant* p = get_participant(serv, i);
			add(par_filtrat, create(p->nume, p->prenume, p->scoruri));
		}
	}
	return par_filtrat;
}



int comparare(Participant* p1, Participant* p2, int criteriu, int directie)
{
	if (criteriu == 1)
	{
		if (strcmp(get_nume(p1), get_nume(p2)) == 0)
			if (directie == 1)
			{
				if (strcmp(get_prenume(p1), get_prenume(p2)) == 1)
					return 1;
				else
					return 2;
			}
			else if (directie == 0)
			{
				if (strcmp(get_prenume(p1), get_prenume(p2)) == -1)
					return 1;
				else
					return 2;
			}
			else return 2;
		if (directie == 1)
		{
			if (strcmp(get_nume(p1), get_nume(p2)) == 1)
				return 1;
			else
				return 2;
		}
		else if (directie == 0)
		{
			if (strcmp(get_nume(p1), get_nume(p2)) == -1)
				return 1;
			else
				return 2;
		}
		else return 2;
	}
	else if (criteriu == 2)
	{
		if (get_scor_mediu(p1) == get_scor_mediu(p2))
		{
			return 0;
		}
		else if (directie == 0)
		{
			if (get_scor_mediu(p1) < get_scor_mediu(p2))
				return 1;
			else
				return 2;
		}
		else if (directie == 1)
		{
			if (get_scor_mediu(p1) > get_scor_mediu(p2))
				return 1;
			else
				return 2;
		}
		else return 2;
	}
	else
		return 2;
}

Lista* sortare(Service* serv, int(*comparare)(Participant*, Participant*, int, int), int criteriu, int directie)
{
	Lista* p_sortat = create_empty();
	for (int i = 0; i < get_dim(&serv->repo); i++)
	{
		Participant* p = get_participant(serv, i);
		add(p_sortat, create(p->nume, p->prenume, p->scoruri));
	}
	for (int i = 0; i < dim(p_sortat) - 1; i++)
	{
		for (int j = i + 1; j < dim(p_sortat); j++)
		{
			if (comparare(get_elem(p_sortat, i), get_elem(p_sortat, j), criteriu, directie) == 1)
			{
				aux = p_sortat->elems[i];
				p_sortat->elems[i] = p_sortat->elems[j];
				p_sortat->elems[j] = aux;
			}
		}
	}
	return p_sortat;
}

void FiltruLab(Lista* p_filtrat, Service* serv, int scor) {
	for (int i = 0; i < get_dim(&serv->repo); i++)
	{
		if (get_scor_mediu(get_participant(serv, i)) <= scor)
		{
			Participant* p = get_participant(serv, i);
			add(p_filtrat, create(p->nume, p->prenume, p->scoruri));
		}
	}
}

void SortareLab(Lista* p_filtrat) {
	for (int i = 0; i < dim(p_filtrat) - 1; i++)
	{
		for (int j = i + 1; j < dim(p_filtrat); j++)
		{
			if (comparare(get_elem(p_filtrat, i), get_elem(p_filtrat, j), 1, 1) == 1)
			{
				aux = p_filtrat->elems[i];
				p_filtrat->elems[i] = p_filtrat->elems[j];
				p_filtrat->elems[j] = aux;
			}
		}
	}
}




int makeUndo(Lista* undoList, Service* serv) {
	int size = dim(undoList);
	if (size == 0)
		return 0;
	else {
		//make undo code here

		makeUndoRepo(undoList, &serv->repo);

		return 1;
	}
}



Lista* filtrareSortataLab(Service* serv, int scor)
{
	Lista* p_filtrat = create_empty();

	FiltruLab(p_filtrat, serv, scor);
	SortareLab(p_filtrat);

	return p_filtrat;
}