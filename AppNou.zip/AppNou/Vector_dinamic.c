#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Vector_dinamic.h"

typedef void* Telem;

Lista* create_empty()
{
	Lista* l = malloc(sizeof(Lista));
	l->n = 0;
	l->cp = 2;
	l->elems = malloc(l->cp * sizeof(Telem));
	return l;
}

void destroyList(Lista* l) {
	destroy(l, destroy_p);
}


void destroy(Lista* l, destroyFunction destroyFCT)
{
	for (int i = 0; i < l->n; i++)
	{
		destroyFCT(l->elems[i]);
	}
	free(l->elems);

	l->elems = NULL;
	l->n = 0;
	free(l);
}

void dublare(Lista* l)
{
	Telem* elems_new = malloc((2 * l->cp) * sizeof(Telem));
	for (int i = 0; i < l->n; i++)
		elems_new[i] = l->elems[i];
	l->cp = 2 * l->cp;
	free(l->elems);
	l->elems = elems_new;
}

void divide(Lista* l)
{
	Telem* elems_new = malloc((l->cp / 2) * sizeof(Telem));
	for (int i = 0; i < l->n; i++)
		elems_new[i] = l->elems[i];
	l->cp = (l->cp / 2);
	free(l->elems);
	l->elems = elems_new;
}


int dim(Lista* l)
{
	return l->n;
}

Telem get_elem(Lista* l, int poz)
{
	//return copy_participant(&l->elems[poz]);
	return l->elems[poz];
}

void add(Lista* l, Telem elem)
{
	if (l->n == l->cp)
		dublare(l);
	l->elems[(l->n)++] = elem;
}

void delete(Lista* l, int poz)
{
	//Telem* elems_new = (Participant*)malloc((l->cp) * sizeof(Telem));
	destroy_p(l->elems[poz]);
	/*
	for (int i = 0; i < poz; i++)
		elems_new[i] = l->elems[i];
	for (int i = poz; i < l->n; i++)
		elems_new[i] = l->elems[i + 1];
	free(l->elems);
	l->elems = elems_new;*/
	for (int i = poz; i < l->n; i++)
		l->elems[i] = l->elems[i + 1];
	l->n = l->n - 1;
	if (l->n <= (l->cp / 2))
		divide(l);
}


int search(Lista* l, Telem elem)
{
	for (int i = 0; i < dim(l); i++)
	{
		if (egale(l->elems[i], elem))
			return i;
	}
	return -1;
}

void update(Lista* l, int poz, Telem elem)
{
	//l->elems[poz] = elem;
	set_nume(l->elems[poz], get_nume(elem));
	set_prenume(l->elems[poz], get_prenume(elem));
	set_scoruri(l->elems[poz], get_scoruri(elem));
}

Lista* copy_lista(Lista* l)
{
	Lista* rez = create_empty();
	for (int i = 0; i < dim(l); i++)
	{
		Telem elem = get_elem(l, i);
		add(rez, copy_participant(elem));
	}
	return rez;
}