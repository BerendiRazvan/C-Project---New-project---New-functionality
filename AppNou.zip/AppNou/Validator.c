#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "Validator.h"

int valid_scor(int scoruri[])
{
	for (int i = 0; i < 10; i++)
	{
		if (scoruri[i] < 0 || scoruri[i] > 10)
			return 1;
	}
	return 0;
}

int valid_nume(char* nume)
{
	if (strcmp(nume, "") == 0)
		return 1;
	else
	{
		for (unsigned int i = 0; i < strlen(nume); i++)
		{
			if (isalpha(nume[i]) == 0)
				return 1;
		}
		return 0;
	}

}

int valid_prenume(char* prenume)
{
	if (strcmp(prenume, "") == 0)
		return 1;
	for (unsigned int i = 0; i < strlen(prenume); i++)
	{

		if (isalpha(prenume[i]) == 0 && prenume[i] != ' ' && prenume[i] != '-')
			return 1;
	}
	return 0;
}

int valid_participant(char* nume, char* prenume, int scoruri[])
{
	int s = 0;
	if (valid_nume(nume) == 0 && valid_prenume(prenume) == 0 && valid_scor(scoruri) == 0)
		return 0;
	else
	{
		if (valid_nume(nume) == 1)
			s += 2;
		if (valid_prenume(prenume) == 1)
			s += 3;
		if (valid_scor(scoruri) == 1)
			s += 4;
		return s;
	}
}