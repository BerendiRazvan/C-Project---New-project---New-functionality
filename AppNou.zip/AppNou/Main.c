#define _CRT_SECURE_NO_WARNINGS
#define _CRTDBG_MAP_ALLOC
#include <stdio.h>
#include "Main.h"
#include <string.h>
#include <crtdbg.h>


int main()
{
	run_all_tests();
	Service serv = init_serv(2);
	Lista* undo = create_empty();

	int scor[10] = { 10, 9, 8, 7, 6, 10, 9, 8, 7, 10 };
	int scor2[10] = { 10, 9, 8, 10, 7, 10, 9, 8, 7, 10 };
	int scor3[10] = { 10, 1, 5, 7, 1, 10, 9, 8, 7, 10 };
	add_serv(&serv, "Boamba", "Emilia Irina", scor, undo);
	add_serv(&serv, "Balaci", "Brianna", scor2, undo);
	add_serv(&serv, "Boamba", "Sebastian", scor3, undo);
	add_serv(&serv, "Aciobanitei", "Andrei", scor2, undo);
	add_serv(&serv, "Birjovanu", "Matei", scor, undo);
	add_serv(&serv, "Gheorghe", "Mara", scor3, undo);


	run_ui(&serv,undo);

	destroy_serv(&serv);
	destroy(undo, destroyList);

	_CrtDumpMemoryLeaks();
	return 0;
}