#ifndef	MAIN_H_
#define MAIN_H_

#include "Domain.h"
#include "Tests.h"
#include "Repository.h"
#include "Service.h"
#include "Console.h"
#include "Validator.h"
#include "Vector_dinamic.h"
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h> 

#endif 