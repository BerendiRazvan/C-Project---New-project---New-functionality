#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Main.h"

Repository init_repo()
{
	Repository repo;
	repo.elems = create_empty();
	return repo;
}

void destroy_repo(Repository* repo)
{
	destroy(repo->elems, destroy_p);
}

int get_dim(Repository* repo)
{
	return dim(repo->elems);
}

Participant* get_parti(Repository* repo, int poz)
{
	return get_elem(repo->elems, poz);
}

int add_repo(Repository* repo, Participant* p, Lista* undo)
{

	int poz = search_repo(repo, p);
	if (poz >= 0)
		return 0;
	else
	{
		add(undo, copy_lista(repo->elems));
		add(repo->elems, p);
	}
	return 1;
}

int delete_repo(Repository* repo, Participant* p, Lista* undo)
{
	int poz = search_repo(repo, p);
	if (poz >= 0)
	{
		add(undo, copy_lista(repo->elems));
		delete(repo->elems, poz);
		return 1;
	}
	return 0;
}

int search_repo(Repository* repo, Participant* p)
{
	return search(repo->elems, p);
}

int update_repo(Repository* repo, Participant* p, Participant* p_nou, Lista* undo)
{
	int poz = search_repo(repo, p);
	if (poz < 0)
	{
		//destroy_p(&p_nou);
		return -1;
	}
	if (search_repo(repo, p_nou) >= 0)
	{
		//destroy_p(&p_nou);
		return 0;
	}
	add(undo, copy_lista(repo->elems));
	update(repo->elems, poz, p_nou);

	return 1;
}


void makeUndoRepo(Lista* undoList, Repository* repo) {
	destroy(repo->elems, destroy_p);
	repo->elems = copy_lista(undoList->elems[undoList->n - 1]);
	destroy(undoList->elems[undoList->n - 1], destroy_p);
	undoList->n -= 1;
}