#ifndef TESTS_H_
#define TESTS_H_
#include<crtdbg.h>

void run_all_tests();

#endif 