#ifndef VECTOR_DINAMIC_
#define VECTOR_DINAMIC_
#define _CRT_SECURE_NO_WARNINGS
#include "Domain.h"

typedef void* Telem;
typedef void (*destroyFunction)(Telem);


typedef struct
{
	// capacitatea maxima
	int cp;

	//nr de elemente
	int n;

	//pointer catre obiectele din repo
	Telem* elems;
}Lista;

Lista* create_empty();
/*
	Aloca spatiul necesar memorarii elementelor
	Returneaza un obiect de tip lista
*/

void destroyList(Lista* l);


void destroy(Lista* l, destroyFunction destroyFCT);
/*
	l - pointer la lista
	Elibereeaza spatiul folosit pentru memorarea elementelor
*/

void dublare(Lista* l);
/*
	l - pointer la lista
	Elibereeaza spatiul folosit pentru memorarea elementelor
*/

void divide(Lista* l);
/*
	l - pointer la lista
	Injumatateste capacitatea listei
*/

int dim(Lista* l);
/*
	l - pointer la lista
	Returneaza numarul de elemente memorate in lista
*/

Telem get_elem(Lista* l, int poz);
/*
	l - pointer la lista
	Returneaza elementul de pe pozitia poz
*/

void add(Lista* l, Telem elem);
/*
	l - pointer la lista
	Adauga un element in lista
*/

void delete(Lista* l, int poz);
/*
	l - pointer la lista
	Sterge un element din lista
*/

int search(Lista* l, Telem elem);
/*
	l - pointer la lista
	elem - elementul pe care il cautam
	Returneaza pozitia elementului din lista daca exista, sau -1 daca nu exista in lista
*/

void update(Lista* l, int poz, Telem elem);
/*
	l - pointer la lista
	poz - intreg, pozitia elementului pe care il modificam
	elem - elementul nou
*/

Lista* copy_lista(Lista* l);
/*
	l - pointer la lista
	Returneaza o noua lista, copie a listei transmise ca parametru
*/

#endif
