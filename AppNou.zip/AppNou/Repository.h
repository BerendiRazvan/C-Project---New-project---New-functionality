#ifndef REPOSITORY_H_
#define REPOSITORY_H_ 
#include "Domain.h"
#include "Vector_dinamic.h"

typedef struct
{
	Lista* elems;
}Repository;

Repository init_repo();
/*
	Se creeaza lista care va memora toti participantii
*/

void destroy_repo(Repository* repo);
/*
	repo -pointer catre obiect de tip Repository
	Se elibereaza spatiul alocat pt memorarea lui
*/

int get_dim(Repository* repo);
/*
	 repo - pointer catre obiect de tip Repository
	 Returneaza numarul de elemente memorate in momentul actual
*/

Participant* get_parti(Repository* repo, int poz);
/*
	 repo - pointer catre obiect de tip Repository
	 poz - intreg
	 Returneaza obiectul de tip Participant de pe pozitia poz din lista
*/

int add_repo(Repository* repo, Participant* p, Lista* lista);
/*
	 repo - pointer catre obiect de tip Repository
	 p - obiect de tip Participant
	 Se adauga un participant in vector
	 Returneaza:
		0 - daca participantul este memorat deja
		1 - daca participantul a fost adaugat
*/

int delete_repo(Repository* repo, Participant* p, Lista* undo);
/*
	 repo - pointer catre obiect de tip Repository
	 p - obiect de tip Participant
	 Se sterge un participant din vector
	 Returneaza:
		0 - daca participantul nu exista
		1 - daca participantul a fost sters
*/

int search_repo(Repository* repo, Participant* p);
/*
	 repo - pointer catre obiect de tip Repository
	 p - obiect de tip Participant
	 Se cauta un participant in vector
	 Returneaza:
		-1 - daca participantul nu exista
		pozitia pe care apare - daca participantul exista
*/

int update_repo(Repository* repo, Participant* p, Participant* p_nou, Lista* undo);
/*
	 repo - pointer catre obiect de tip Repository
	 p, p_nou - obiecte de tip Participant
	 Se modifica un participant din vector cu informatiile participantului p_nou
	 Returneaza:
		-1 - daca participantul pe care vrem sa il modificam nu exista
		0 - daca participantul nou este memorat deja
		1 - daca participantul a fost modificat cu succes
*/

void makeUndoRepo(Lista* undoList, Repository* repo);
/*
	Functie care realizeaza undo

	Functie de tip void

	Parametrii:
		<Lista*> - undoList (Lista de liste)
		<Repository*> - repo

	Modifica elementele din repository ultima lista din undoList
*/

#endif 
