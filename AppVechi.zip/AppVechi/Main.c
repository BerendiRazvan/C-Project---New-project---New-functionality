#include <stdio.h>
#include "Main.h"
#include <string.h>

int main()
{
	run_all_tests();
	Service serv = init_serv(2);

	int scor[10] = { 10, 9, 8, 7, 6, 10, 9, 8, 7, 10 };
	int scor2[10] = { 10, 9, 8, 10, 7, 10, 9, 8, 7, 10 };
	int scor3[10] = { 10, 10, 5, 7, 10, 10, 9, 8, 7, 10 };
	add_serv(&serv, "Boamba", "Emilia Irina", scor);
	add_serv(&serv, "Balaci", "Brianna", scor2);
	add_serv(&serv, "Boamba", "Sebastian", scor3);
	add_serv(&serv, "Aciobanitei", "Andrei", scor2);
	add_serv(&serv, "Birjovanu", "Matei", scor);
	add_serv(&serv, "Gheorghe", "Mara", scor3);
	
	run_ui(&serv);

	destroy_serv(&serv);
	_CrtDumpMemoryLeaks();
	return 0;
}