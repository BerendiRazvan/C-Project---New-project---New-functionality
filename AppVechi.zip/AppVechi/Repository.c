#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Main.h"

Repository init_repo()
{
	Repository repo;
	repo.elems = create_empty();
	return repo;
}

void destroy_repo(Repository* repo)
{
	destroy(&repo->elems);
}

int get_dim(Repository* repo)
{
	return dim(&repo->elems);
}

Participant get_parti(Repository* repo, int poz)
{
	return get_elem(&repo->elems, poz);
}

int add_repo(Repository* repo, Participant p)
{
	int poz = search_repo(repo, p);
	if (poz >= 0)
		return 0;
	else
	{
		add(&repo->elems, p);
	}
	return 1;
}

int delete_repo(Repository* repo, Participant p)
{
	int poz = search_repo(repo, p);
	if (poz >= 0)
	{
		delete(&repo->elems, poz);
		return 1;
	}
	return 0;
}

int search_repo(Repository* repo, Participant p)
{
	return search(&repo->elems, p);
}

int update_repo(Repository* repo, Participant p, Participant p_nou)
{
	int poz = search_repo(repo, p);
	if (poz < 0)
	{
		//destroy_p(&p_nou);
		return -1;
	}
	if (search_repo(repo, p_nou) >= 0)
	{
		//destroy_p(&p_nou);
		return 0;
	}
	update(&repo->elems, poz, p_nou);
	//destroy_p(&p);
	//set_nume(&(repo->p[poz]), get_nume(p_nou));
	//set_prenume(&(repo->p[poz]), get_prenume(p_nou));
	//set_scoruri(&(repo->p[poz]), get_scoruri(p_nou));
	return 1;
}
