#ifndef CONSOLE_H__
#define CONSOLE_H__
#include "Service.h"
#define _CRT_SECURE_NO_WARNINGS

int citire_intreg();
void print_menu();
void print_menu_update();
void print_menu_filtrare();
void print_menu_sortare();
void print(Participant p);
void afisare_ui(Service* serv);
void add_ui(Service* serv);
void delete_ui(Service* serv);
void update_scor_ui(Service* serv);
void update_all_ui(Service* serv);
void exit_ui(); 
void ui_filtrare_scor(Service* serv);
void ui_filtrare_nume(Service* serv);
void ui_sortare_nume(Service* serv, int criteriu, int directie);
void ui_sortare_scor(Service* serv, int criteriu, int directie);
void run_ui_filtrare(Service* serv);
void run_ui_sortare(Service* serv);
void run_ui_update(Service* serv);
void run_ui(Service* serv);

#endif 
