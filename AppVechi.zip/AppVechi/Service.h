#ifndef SERVICE_H_
#define SERVICE_H_
#include "Repository.h"
#include "Validator.h"

typedef struct
{	
	//pointer catre obiect de tip Repository 
	Repository repo;
}Service;

Service init_serv();
/*
	apeleaza functia de initializare a repo-ului
*/

void destroy_serv(Service* serv);
/*
	Se elibereaza spatiul alocat memorarii service-ului, si se apeleaza fct de distrugere a repo-ului
*/

int add_serv(Service* serv, char* nume, char* prenume, int scoruri[]);
/*
	serv - pointer catre obiect de tip Service
	nume - pointer catre un string
	prenume - pointer catre un string
	scoruri - vector de intregi
	Se memoreaza un participant 
	Returneaza:
		daca participantul este valid:
			0 - daca participantul este memorat deja
			1 - daca participantul a fost adaugat
		2 - numele nu e valid
		3 - prenumele nu e valid
		4- scorurile nu sunt valide
		5 - nume, prenume invalide
		6 - nume, scoruri invalide
		7 - prenume, scoruri invalide
		9 - toate informatiile invalide
		
*/

int delete_serv(Service* serv, char* nume, char* prenume);
/*
	serv - pointer catre obiect de tip Service
	nume - pointer catre un string
	prenume - pointer catre un string
	Se sterge un participant
	Returneaza:
		daca participantul este valid:
			0 - daca participantul nu exista
			1 - daca participantul a fost sters

*/

int search_serv(Service* serv, char* nume, char* prenume);
/*
	serv - pointer catre obiect de tip Service
	nume - pointer catre un string
	prenume - pointer catre un string
	Se cauta participantul cu numele si prenumele dat
	Returneaza:
		-1 - daca participantul nu exista
		pozitia pe care apare - daca participantul exista
*/

int update_all_serv(Service* serv, char* nume, char* prenume, char* nume_nou, char* prenume_nou, int scoruri[]);
/*
	serv - pointer catre obiect de tip Service
	nume, nume_nou - pointer catre un string
	prenume, prenume_nou - pointer catre un string
	scoruri - vector de intregi
	Se actualizeaza un participant
	Returneaza:
		-1 - daca participantul pe care vrem sa il modificam nu exista
		0 - daca participantul nou este memorat deja
		1 - daca participantul a fost modificat cu succes

*/

void update_scor_serv(Service* serv, char*nume, char* prenume, int poz, int scor);
/*
	serv - pointer catre obiect de tip Service
	nume - pointer catre un string
	prenume - pointer catre un string
	scor - intreg
	poz - intreg
	Schimba valoarea scorului de pe pozitia poz+1 cu valoarea scor
*/

Lista* get_participanti(Service* serv);
/*
	serv - pointer catre obiect de tip Service
	Returneaza un pointer catre lista in care sunt memorati participantii
*/

int get_nr_participanti(Service* serv);
/*
	serv - pointer catre obiect de tip Service
	Returneaza nr de participanti memorati
*/

Participant get_participant(Service* serv, int poz);
/*
	serv - pointer catre obiect de tip Service
	Returneaza un obiect de tip Participant, memorat pe pozitia poz
*/

int comp_nume(Lista p_sortat, int i, int j, int tip);
/*
	p_sortat - lista de participanti
	i, j - intreg, pozitiile pe care dorim sa le comparam 
	tip - tipul dupa care comparam, daca vrem ca crescator sau descrescator
		1 - alfabetic
		0 - invers alfabetic
*/

int comp_prenume(Lista p_sortat, int i, int j, int tip);
/*
	p_sortat - lista de participanti
	i, j - intreg, pozitiile pe care dorim sa le comparam
	tip - tipul dupa care comparam, daca vrem ca crescator sau descrescator
		1 - alfabetic
		0 - invers alfabetic
*/

int comp_scor(Lista p_sortat, int i, int j, int tip);
/*
	p_sortat - lista de participanti
	i, j - intreg, pozitiile pe care dorim sa le comparam
	tip - tipul dupa care comparam, daca vrem ca crescator sau descrescator
		1 - crescator
		0 - descrescator
*/

Lista filtrare1(Service* serv, int scor);
/*
	serv - pointer la service 
	scor - intreg, scorul ca si criteriu
	Functia creeaza si returneaza o lista de participanti care au scorul mai mic decat scorul transmis
*/

Lista filtrare2(Service* serv, char c);
/*
	serv - pointer la service
	c - caracter
	Functia creeaza si returneaza o lista de participanti a caror nume incepe cu caracterul transmis
*/

//Lista sortare_nume(Service* serv, int tip);
///*
//	serv - pointer la service
//	tip - intreg, tipul dupa care vrem sa sortam, crescator sau descrescator
//		1 - alfabetic
//		0 - invers alfabetic
//	Functia creeaza si returneaza o lista de participanti sortati in functie de nume
//*/
//
//Lista sortare_scor(Service* serv, int tip);
///*
//	serv - pointer la service
//	tip - intreg, tipul dupa care vrem sa sortam, crescator sau descrescator
//		1 - crescator
//		0 - descrescator
//	Functia creeaza si returneaza o lista de participanti sortati in functie de scor
//*/

int comparare(Participant p1, Participant p2, int criteriu, int directie);
/*
	p1, p2 - Participanti
	criteriu: 1 - dupa scor mediu
			  2 - dupa nume
	directie: 0 - crescator / alfabetic
			  1 - descrescator / invers alfabetic
*/

Lista sortare(Service* serv, int(*comparare)(Participant, Participant, int, int), int criteriu, int directie);
/*
	serv - pointer la service
	comparare - functia de comparare
	criteriu - criteriu de sortare
			1 - dupa scor mediu
			2 - dupa nume
	directie - directia de sortare
			0 - crescator / alfabetic
			1 - descrescator / invers alfabetic
*/

#endif 
