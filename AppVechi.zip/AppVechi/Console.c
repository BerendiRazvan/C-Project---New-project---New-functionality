#include <stdio.h>
#include <string.h>
#include "Console.h"
#include <conio.h>


int citire_intreg()
{
	/*
		Functia nu primeste niciun parametru
		Se verifica ca numarul citit sa fie intreg, sa nu fie citite caractere, caz in care se afiseaza un mesaj corespunzator
		Se returneaza input-ul citit corect, ca si numar
	*/
	int valid, cmd, temp;
	valid = scanf("%d", &cmd);
	while (valid != 1)
	{
		while ((temp = getchar()) != EOF && temp != '\n');
		printf("Introduceti numere, nu caractere!!\n");
		valid = scanf("%d", &cmd);
	}
	return cmd;
}

void print_menu()
{
	printf("\n       MENIU\n\n");
	printf("1. AFISARE PARTICIPANTI\n");
	printf("2. ADAUGARE PARTICIPANT\n");
	printf("3. STERGE PARTICIPANT\n");
	printf("4. ACTUALIZARE PARTICIPANT\n");
	printf("5. FILTRARE\n");
	printf("6. SORTARE\n");
	printf("7. IESIRE\n");
	printf("\nIntroduceti comanda: ");
}

void print_menu_update()
{
	printf("\n       ACTUALIZARE\n\n");
	printf("1. ACTUALIZARE SCORURI\n");
	printf("2. ACTUALIZARE TOATE INFORMATIILE\n");
	printf("3. IESIRE\n");
	printf("\nIntroduceti comanda: ");
}

void print_menu_filtrare()
{
	printf("\n       FILTRARE\n\n");
	printf("1. FILTRARE DUPA SCOR\n");
	printf("2. FILTRARE DUPA PRIMA LITERA DIN NUME\n");
	printf("3. IESIRE\n");
	printf("\nIntroduceti comanda: ");
}

void print_menu_sortare()
{
	printf("\n       SORTARE\n\n");
	printf("1. SORTARE DUPA NUME CRESCATOR\n");
	printf("2. SORTARE DUPA NUME DESCRESCATOR\n");
	printf("3. SORTARE DUPA SCOR CRESCATOR\n");
	printf("4. SORTARE DUPA SCOR DESCRESCATOR\n");
	printf("5. IESIRE\n");
	printf("\nIntroduceti comanda: ");
}

void print(Participant p)
{
	int* scor;
	scor = get_scoruri(p);
	printf("\nNUME: %s", get_nume(p));
	printf("\nPRENUME: %s", get_prenume(p));
	printf("\nSCORURI: ");
	for (int i = 0; i < 9; i++)
	{
		printf("%d, ", scor[i]);
	}
	printf("%d \n", scor[9]);
	printf("SCOR MEDIU: %d\n", get_scor_mediu(p));
}

void afisare_ui(Service* serv)
{	
	printf("\n     AFISARE\n");
	printf("\nParticipantii sunt:\n");
	int nr = get_nr_participanti(serv);
	Lista *l = get_participanti(serv);
	for (int i = 0; i < nr; i++)
	{
		print(get_elem(l, i));
	}
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void add_ui(Service* serv)
{
	int scoruri[10];
	char nume[30], prenume[30];
	printf("\n      ADAUGARE\n");
	printf("\nIntroduceti numele participantului: ");
	while (getchar() != '\n');
	scanf("%[^\n]%*c", nume);
	printf("Introduceti prenumele participantului: ");
	scanf("%[^\n]%*c", prenume);
	printf("Introduceti scoruri: \n");
	for (int i = 0; i < 10; i++)
	{
		printf("Introduceti scorul cu numarul %d: ", i+1);
		scoruri[i] = citire_intreg();
	}
	int err = add_serv(serv, nume, prenume, scoruri);
	if (err == 1)
		printf("\nAdaugarea a fost efectuata cu succes!\n");
	else if (err == 0)
		printf("\nMai exista un participant cu acelasi nume si prenume!\n");
	else if (err == 12)
		printf("\nToate informatiile sunt invalide!\n");
	else if (err == 5)
		printf("\nNume si prenume invalide!\n");
	else if (err == 6)
		printf("\nNume si scoruri invalide!\n");
	else if (err == 7)
		printf("\nPrenume si scoruri invalide!\n");
	else if (err == 2)
		printf("\nNume invalid!\n");
	else if (err == 3)
		printf("\nPrenume invalid!\n");
	else if (err == 4)
		printf("\nScoruri invalide!\n");
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void delete_ui(Service* serv)
{
	char nume[30], prenume[30];
	printf("\n      STERGERE\n");
	printf("\nIntroduceti numele participantului: ");
	while (getchar() != '\n');
	scanf("%[^\n]%*c", nume);
	printf("Introduceti prenumele participantului: ");
	scanf("%[^\n]%*c", prenume);
	if (valid_nume(nume) == 0 && valid_prenume(prenume) == 0)
	{
		if (delete_serv(serv, nume, prenume) == 1)
			printf("\nStergerea a fost efectuata cu succes!\n");
		else
			printf("\nNu exista participantul cu numele si prenumele dat!\n");
	}
	else if (valid_nume(nume) == 1 && valid_prenume(prenume) == 1)
		printf("\nNume si prenume invalid!\n");
	else if (valid_nume(nume) == 1)
		printf("\nNume invalid!\n");
	else
		printf("\nPrenume invalid!\n");
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void update_scor_ui(Service* serv)
{
	char nume[30], prenume[30];
	printf("\n      ACTUALIZAREA UNUI SCOR \n");
	printf("\nIntroduceti numele participantului caruia doriti sa ii modificati datele: ");
	while (getchar() != '\n');
	scanf("%[^\n]%*c", nume);
	printf("Introduceti prenumele participantului caruia doriti sa ii modificati datele: ");
	scanf("%[^\n]%*c", prenume);
	if (search_serv(serv, nume, prenume) >= 0)
	{
		printf("Introduceti numarul scorului pe care doriti sa il modificati: ");
		int poz = citire_intreg();
		printf("Introduceti noua valoare:");
		int scor = citire_intreg();
		update_scor_serv(serv, nume, prenume, poz, scor);
		printf("\nScorul a fost modificat!\n");
	}
	else
		printf("\nNu exista niciun participant cu acest nume si prenume!\n");
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}
	
void update_all_ui(Service* serv)
{
	int scoruri[10];
	char nume_vechi[30], prenume_vechi[30], nume_nou[30], prenume_nou[30];
	printf("\n      ACTUALIZAREA TUTUROR INFORMATIILOR\n");
	printf("\nIntroduceti numele participantului caruia doriti sa ii modificati datele: ");
	while (getchar() != '\n');
	scanf("%[^\n]%*c", nume_vechi);
	printf("Introduceti prenumele participantului caruia doriti sa ii modificati datele: ");
	scanf("%[^\n]%*c", prenume_vechi);
	if (search_serv(serv, nume_vechi, prenume_vechi) >= 0)
	{
		printf("Introduceti numele nou: ");
		scanf("%[^\n]%*c", nume_nou);
		printf("Introduceti prenumele nou: ");
		scanf("%[^\n]%*c", prenume_nou);
		if (search_serv(serv, nume_nou, prenume_nou) == -1)
		{
			printf("Introduceti scoruri noi: \n");
			for (int i = 0; i < 10; i++)
			{
				printf("Introduceti scorul cu numarul %d: ", i + 1);
				scoruri[i] = citire_intreg();
			}
			update_all_serv(serv, nume_vechi, prenume_vechi, nume_nou, prenume_nou, scoruri);
			printf("\nModificarea a fost realizata cu succes!\n");
		}
		else
			printf("\nParticipantul este inscris deja!\n");
	}
	else
		printf("\nNu exista participantul cu numele si prenumele dat!\n");
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void exit_ui()
{
	printf("Ati iesit din aplicatie!\nCiao!");
}

void ui_filtrare_nume(Service* serv)
{
	printf("\nIntroduceti caracterul:\n");
	while (getchar() != '\n');
	char car;
	scanf("%c", &car);
	Lista l = filtrare2(serv, car);
	for (int i = 0; i < dim(&l); i++)
	{
		print(get_elem(&l, i));
	}
	destroy(&l);
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void ui_filtrare_scor(Service* serv)
{
	printf("\nIntroduceti scorul:\n");
	int scor = citire_intreg();
	Lista l = filtrare1(serv, scor);
	for (int i = 0; i < dim(&l); i++)
	{
		print(get_elem(&l, i));
	}
	destroy(&l);
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void ui_sortare_nume(Service* serv, int criteriu,  int directie)
{
	Lista l = sortare(serv, comparare, criteriu, directie);
	for (int i = 0; i < dim(&l); i++)
	{
		print(get_elem(&l, i));
	}
	destroy(&l);
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void ui_sortare_scor(Service* serv, int criteriu, int directie)
{
	Lista l = sortare(serv,comparare, criteriu, directie);
	for (int i = 0; i < dim(&l); i++)
	{
		print(get_elem(&l, i));
	}
	destroy(&l);
	printf("\nApasati orice tasta pentru a va reintoarce la meniu: ");
	getch();
	system("cls");
}

void run_ui_filtrare(Service* serv)
{
	int cmd, n, ok = 1;
	while (ok)
	{
		print_menu_filtrare();
		if (scanf("%d", &n) < 1)
		{
			while (getchar() != '\n');
			cmd = -1;
		}
		else
			cmd = n;
		if (cmd != -1)
		{
			switch (cmd)
			{
			case 1:
				system("cls");
				ui_filtrare_scor(serv);
				break;
			case 2:
				system("cls");
				ui_filtrare_nume(serv);
				break;
			case 3:
				ok = 0;
				system("cls");
				break;
			default:
				printf("\nAlegeti o comanda din meniu!\n");
			}
		}
		else
			printf("\nComanda invalida!!\n");
	}
}

void run_ui_sortare(Service* serv)
{
	int cmd, n, ok = 1;
	while (ok)
	{
		print_menu_sortare();
		if (scanf("%d", &n) < 1)
		{
			while (getchar() != '\n');
			cmd = -1;
		}
		else
			cmd = n;
		if (cmd != -1)
		{
			switch (cmd)
			{
			case 1:
				system("cls");
				ui_sortare_nume(serv, 1, 1);
				break;
			case 2:
				system("cls");
				ui_sortare_nume(serv, 1, 0);
				break;
			case 3:
				system("cls");
				ui_sortare_scor(serv, 2, 1);
				break;
			case 4:
				system("cls");
				ui_sortare_scor(serv, 2, 0);
				break;
			case 5:
				ok = 0;
				system("cls");
				break;
			default:
				printf("\nAlegeti o comanda din meniu!\n");
			}
		}
		else
			printf("\nComanda invalida!!\n");
	}
}

void run_ui_update(Service* serv)
{
	int cmd, n, ok = 1;
	while (ok)
	{
		print_menu_update();
		if (scanf("%d", &n) < 1)
		{
			while (getchar() != '\n');
			cmd = -1;
		}
		else
			cmd = n;
		if (cmd != -1)
		{
			switch (cmd)
			{
			case 1:
				system("cls");
				update_scor_ui(serv);
				break;
			case 2:
				system("cls");
				update_all_ui(serv);
				break;
			case 3:
				ok = 0;
				system("cls");
				break;
			default:
				printf("\nAlegeti o comanda din meniu!\n");
			}
		}
		else
			printf("\nComanda invalida!!\n");
	}
}

void run_ui(Service* serv)
{	
	int cmd, n, ok = 1;
	while (ok)
	{
		print_menu();
		if (scanf("%d", &n) < 1)
		{
			while (getchar() != '\n');
			cmd = -1;
		}
		else
			cmd = n;
		if (cmd != -1)
		{
			switch (cmd)
			{
			case 1:
				system("cls");
				afisare_ui(serv);
				break;
			case 2:
				system("cls");
				add_ui(serv);
				break;
			case 3:
				system("cls");
				delete_ui(serv);
				break;
			case 4:
				system("cls");
				run_ui_update(serv);
				break;
			case 5:
				system("cls");
				run_ui_filtrare(serv);
				break;
			case 6:
				system("cls");
				run_ui_sortare(serv);
				break;
			case 7:
				exit_ui();
				ok = 0;
				break;
			default:
				printf("\nAlegeti o comanda din meniu!\n");
			}
		}
		else
			printf("\nComanda invalida!!\n");
	}
}