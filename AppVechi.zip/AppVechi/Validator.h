#ifndef VALIDATOR_H_
#define VALIDATOR_H_

int valid_scor(int scoruri[]);
/*
	scoruri - vactor de intregi
	Returneaza 1 daca este cel putin un element care  nu apartine intervalului [0,10]
	Returneaza 0 daca toate apartin intervalului
*/

int valid_nume(char* nume);
/*
	nume - pointer catre un string
	Returneaza 1 daca stringul contine si alte caractere in afara de litere
	Returneaza 0 daca toate caractrele sunt litere
*/

int valid_prenume(char* prenume);
/*
	prenume - pointer catre un string
	Returneaza 1 daca stringul contine si alte caractere in afara de litere, caracterul spatiu si '-'
	Returneaza 0 daca toate caractrele sunt litere, sau spatiu sau -
*/

int valid_participant(char* nume, char* prenume, int scoruri[]);
/*
	nume - pointer catre un string
	prenume - pointer catre un string
	scoruri - vector de intregi
	Returneaza 0 daca toti parametri sunt valizi
	Returneaza:
		2 - numele nu e valid
		3 - prenumele nu e valid
		4- scorurile nu sunt valide
		5 - nume, prenume invalide
		6 - nume, scoruri invalide
		7 - prenume, scoruri invalide
		9 - toati parametri invalizi
*/

#endif 
