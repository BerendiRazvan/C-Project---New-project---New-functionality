#ifndef DOMAIN_H_
#define DOMAIN_H_
#include <stdlib.h>
#define _CRT_SECURE_NO_WARNINGS


typedef struct
{
	char* nume;
	char* prenume;
	int* scoruri; 
}Participant;

Participant create(char* nume, char* prenume, int* scoruri);
/*
	nume - string, numele unui participant
	prenume - string, prenumele unui participant
	scoruri - pointer la un vector de numere intregi, scorurile unui participant
	Functia creeaza si returneaza un obiect de tip Participant
*/

char* get_nume(Participant p);
/*
	p - obiect de tip Participant
	Returneaza campul nume al obiectului de tip Participant, un string
*/

char* get_prenume(Participant p);
/*
	p - obiect de tip Participant
	Returneaza campul prenume al obiectului de tip Participant, un string
*/

int* get_scoruri(Participant p);
/*
	p - obiect de tip Participant
	Returneaza campul scoruri al obiectului de tip Participant
*/

int get_scor_mediu(Participant p);
/*
	p - obiect de tip Participant
	Returneaza media aritmetica, ca si intreg, a elementelor din campul scoruri al obiectului de tip Participant
*/

void set_nume(Participant* p, char* nume);
/*
	p - obiect de tip Participant
	nume - string
	Seteaza campul nume al obiectului de tip Participant cu valoarea parametrului nume
*/

void set_prenume(Participant* p, char* prenume);
/*
	p - obiect de tip Participant
	prenume - string
	Seteaza campul prenume al obiectului de tip Participant cu valoarea parametrului prenume
*/

void set_scor(Participant* p, int poz, int scor);
/*
	p - obiect de tip Participant
	poz - intreg
	scor - intreg
	Seteaza elementul de pe pozitia poz al campului scoruri, al obiectului de tip Participant, cu valoarea parametrului scor
*/

void set_scoruri(Participant* p, int scoruri[]);
/*
	p - obiect de tip Participant
	scoruri - vectori de elemente intregi
	Seteaza campul scoruri, al obiectului de tip Participant, cu valoarile parametrului scoruri
*/

int egale(Participant p1, Participant p2);
/*
	p1,p2 - obiecte de tip Participant
	Compara cele 2 obiecte pe baza campurilor nume si prenume
	Returneaza 1 daca sunt egale, 0 daca nu sunt
*/

void destroy_p(Participant* p);
/*
	Functia elibereaza spatiul folosit pentru memorarea unui obiect de tip Participant
*/

Participant copy_participant(Participant* p);
/*
	p - pointer catre un Participant
	Functia creeaza si returneaza un alt obiect de tip Participant, cu campurile egale cu ale participantului transmis 
		ca parametru
*/

#endif 
