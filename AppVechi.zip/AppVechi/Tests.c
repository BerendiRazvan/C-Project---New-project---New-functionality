#include "Main.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS	

void test_domain()
{
	int scor[10] = { 10, 9, 8, 7, 6, 10, 9, 8, 7, 10 };
	int* scor_test;
	Participant p1 = create("Boamba", "Emilia Irina", scor);
	
	//getteri
	assert(strcmp(get_nume(p1), "Boamba") == 0);
	assert(strcmp(get_prenume(p1), "Emilia Irina") == 0);
	scor_test = get_scoruri(p1);
	for (int i = 0; i < 10; i++)
	{
		assert(scor[i] == scor_test[i]);
	}
	assert(get_scor_mediu(p1) == 8);
	
	//setteri
	set_nume(&p1, "Lupascu");
	assert(strcmp(get_nume(p1), "Lupascu") == 0);
	set_prenume(&p1, "Irina");
	assert(strcmp(get_prenume(p1), "Irina") == 0);
	assert(p1.scoruri[1] == 9);
	set_scor(&p1, 2, 10);
	assert(p1.scoruri[1] == 10);
	int s2[10] = { 10, 9, 10, 10, 9, 10, 9, 10, 9, 10 };
	set_scoruri(&p1, s2);
	scor_test = get_scoruri(p1);
	for (int i = 0; i < 10; i++)
	{
		assert(scor_test[i] == s2[i]);
	}
	Participant p2 = create("Lupascu", "Irina", scor);
	assert(egale(p1, p2) == 1);
	Participant p3 = create("Lupascu", "Emilia Irina", scor);
	assert(egale(p1, p3) == 0);

	Participant p4 = copy_participant(&p1);
	assert(egale(p1, p4) == 1);

	destroy_p(&p1);
	destroy_p(&p2);
	destroy_p(&p3);
	destroy_p(&p4);
}

void test_repo()
{
	Repository repo = init_repo();
	
	//test add
	int scor[10] = { 10, 9, 8, 7, 6, 10, 9, 8, 7, 10 };
	Participant p1 = create("Boamba", "Emilia Irina", scor);
	Participant p2 = create("Balaci", "Brianna", scor);
	assert(add_repo(&repo, p1) == 1);
	assert(add_repo(&repo, p1) == 0);
	assert(get_dim(&repo) == 1);
	assert(add_repo(&repo, p2) == 1);
	assert(get_dim(&repo) == 2);

	//test delete 
	assert(delete_repo(&repo, p2) == 1);
	assert(get_dim(&repo) == 1);
	assert(delete_repo(&repo, p2) == 0);
	 
	//test search
	assert(search_repo(&repo, p2) == -1);
	assert(search_repo(&repo, p1) == 0);
	assert(egale(get_parti(&repo, search_repo(&repo, p1)), p1) == 1);

	p2 = create("Balaci", "Brianna", scor);
	assert(add_repo(&repo, p2) == 1);
	Participant p3 = create("Dada", "Gabi", scor);
	assert(add_repo(&repo, p3) == 1);

	assert(search_repo(&repo, p2) == 1);
	assert(search_repo(&repo, p3) == 2);


	//test update
	int scor_test[10] = { 10, 10, 10, 10, 10, 10, 10, 10, 10, 10 };
	Participant p4 = create("Apostol", "Delia", scor_test);
	assert(update_repo(&repo, p4, p1) == -1);
	assert(update_repo(&repo, p1, p2) == 0);
	assert(update_repo(&repo, p2, p4) == 1);
	update_repo(&repo, p2, p4);
	//p4 = create("Apostol", "Delia", scor_test);
	assert(egale(get_parti(&repo, 1), p4) == 1);
	for (int i = 0; i < 10; i++)
	{
		assert(get_scoruri(get_parti(&repo, 1))[i] == get_scoruri(p4)[i]);
	}/**/
	//destroy_p(&p1);
	//destroy_p(&p2);
	//destroy_p(&p3);
	destroy_p(&p4);
	destroy_repo(&repo);
}

void test_serv()
{
	//Repository* repo = init_repo(2);
	Service serv = init_serv(1);
	

	int scor[10] = { 10, 9, 8, 7, 6, 10, 9, 8, 7, 10 }, scor_test[10] = {10,10,10,10,10,10,1,10,10,10};
	Participant p1 = create("Boamba", "Emilia Irina", scor);
	Participant p2 = create("Balaci", "Brianna", scor);
	Participant p3 = create("Boamba", "Irina", scor_test);

	//test add
	assert(add_serv(&serv, "Boamba", "Emilia Irina", scor) == 1);
	assert(add_serv(&serv, "Balaci", "Brianna", scor) == 1);
	assert(add_serv(&serv, "Boamba", "Emilia Irina", scor_test) == 0);
	scor_test[0] = -9;
	assert(add_serv(&serv, "", "", scor_test) == 9);
	assert(add_serv(&serv, "Anton", "", scor_test) == 7);
	assert(add_serv(&serv, "", "Emilia", scor_test) == 6);
	assert(add_serv(&serv, "Pintilie", "Stefan", scor_test) == 4);
	scor_test[0] = 10;
	assert(add_serv(&serv, "", "Stefan", scor_test) == 2);
	assert(add_serv(&serv, "Pintilie", "", scor_test) == 3);

	//test get_nr
	assert(get_nr_participanti(&serv) == 2);

	//test get_participanti si get_participant
	Lista* aux = get_participanti(&serv);
	assert(egale(aux->elems[0], p1) == 1);
	assert(egale(aux->elems[1], p2) == 1);

	assert(egale(get_participant(&serv, 0), p1) == 1);
	assert(egale(get_participant(&serv, 1), p2) == 1);

	//test delete
	assert(delete_serv(&serv, "Boamba", "Emilia Irina") == 1);
	assert(delete_serv(&serv, "Boamba", "Emilia Irina") == 0);

	//test update
	assert(update_all_serv(&serv, "Balaci", "Brianna", "Boamba", "Irina", scor_test) == 1);
	assert(egale(get_parti(&serv.repo, 0), p3) == 1);
	assert(update_all_serv(&serv, "Balaci", "Brianna", "Boamba", "Irina", scor_test) == -1);
	add_serv(&serv, "Balaci", "Brianna", scor);
	assert(update_all_serv(&serv, "Boamba", "Irina", "Balaci", "Brianna", scor_test) == 0);
	
	update_scor_serv(&serv, "Boamba", "Irina", 1, 0);
	assert(get_participant(&serv, 0).scoruri[0] == 0);
	
	//test filtrare1
	Lista aux2 = filtrare1(&serv, 9);
	assert(dim(&aux2) == 2);
	for (int i = 0; i < dim(&aux2); i++)
	{
		assert(egale(aux2.elems[i], get_parti(&serv.repo, i) )== 1);
	}
	
	Lista aux3 = filtrare1(&serv, 6);
	assert(dim(&aux3) == 0);

	int ss[10] = { 10, 10, 10, 10, 10,10,9,10,9,10 };
	update_all_serv(&serv, "Boamba", "Irina", "Boamba", "Emi", ss);

	Lista aux4 = filtrare1(&serv, 8);
	assert(dim(&aux4) == 1);
	assert(egale(get_elem(&aux4, 0), get_participant(&serv, 1)) == 1);

	//test filtrare2
	Lista aux5 = filtrare2(&serv, 'b');
	assert(dim(&aux5) == 2);
	for (int i = 0; i < dim(&aux5); i++)
	{
		assert(egale(get_elem(&aux5, i), get_participant(&serv, i)) == 1);
	}

	Lista aux6 = filtrare2(&serv, 'c');
	assert(dim(&aux6) == 0);

	add_serv(&serv, "Ciuntu", "Andi", scor);
	Lista aux7 = filtrare2(&serv, 'c');
	assert(dim(&aux7) == 1);
	assert(egale(get_elem(&aux7, 0), get_participant(&serv, 2)) == 1);
		/*
	//test sortare1
	Lista aux8 = sortare(&serv, comparare, 2, 0);
	assert(dim(&aux8) == 3);
	printf("%s", get_nume(aux8.elems[0]));
	assert(strcmp(get_nume(aux8.elems[0]), "Balaci") == 0);
	assert(strcmp(get_nume(aux8.elems[1]), "Boamba") == 0);
	assert(strcmp(get_nume(aux8.elems[2]), "Ciuntu") == 0);

	Lista aux11 = sortare(&serv, comparare, 2, 1);
	assert(dim(&aux11) == 3);
	assert(strcmp(get_nume(aux11.elems[0]), "Ciuntu") == 0);
	assert(strcmp(get_nume(aux11.elems[1]), "Boamba") == 0);
	assert(strcmp(get_nume(aux11.elems[2]), "Balaci") == 0);
	*/
	int scc[10] = { 10,10,10,10,10,10,10,10,10,10 };
	add_serv(&serv, "Ardelean", "George", scc);

	//test sortare2
	//Lista aux9 = sortare_scor(&serv, 1);
	Lista aux9 = sortare(&serv, comparare, 2, 1);

	assert(strcmp(get_nume(aux9.elems[3]), "Ardelean") == 0);
	assert(strcmp(get_nume(aux9.elems[2]), "Boamba") == 0);
	assert(strcmp(get_nume(aux9.elems[1]), "Ciuntu") == 0);
	assert(strcmp(get_nume(aux9.elems[0]), "Balaci") == 0);

	Lista aux10 = sortare(&serv, comparare, 2, 0);

	assert(strcmp(get_nume(aux10.elems[0]), "Ardelean") == 0);
	assert(strcmp(get_nume(aux10.elems[1]), "Boamba") == 0);
	assert(strcmp(get_nume(aux10.elems[2]), "Ciuntu") == 0);
	assert(strcmp(get_nume(aux10.elems[3]), "Balaci") == 0);

	add_serv(&serv, "Boamba", "Sebi", scor_test);
	Lista aux12 = sortare(&serv, comparare, 1, 0);
	assert(dim(&aux12) == 5);
	assert(strcmp(get_nume(aux12.elems[0]), "Ciuntu") == 0);
	assert(strcmp(get_nume(aux12.elems[1]), "Boamba") == 0);
	assert(strcmp(get_prenume(aux12.elems[1]), "Sebi") == 0);
	assert(strcmp(get_nume(aux12.elems[2]), "Boamba") == 0);
	assert(strcmp(get_prenume(aux12.elems[2]), "Emi") == 0);
	assert(strcmp(get_nume(aux12.elems[3]), "Balaci") == 0);
	assert(strcmp(get_nume(aux12.elems[4]), "Ardelean") == 0);

	Lista aux13 = sortare(&serv, comparare, 1, 1);
	assert(dim(&aux13) == 5);
	assert(strcmp(get_nume(aux13.elems[4]), "Ciuntu") == 0);
	assert(strcmp(get_nume(aux13.elems[3]), "Boamba") == 0);
	assert(strcmp(get_prenume(aux13.elems[3]), "Sebi") == 0);
	assert(strcmp(get_nume(aux13.elems[2]), "Boamba") == 0);
	assert(strcmp(get_prenume(aux13.elems[2]), "Emi") == 0);
	assert(strcmp(get_nume(aux13.elems[1]), "Balaci") == 0);
	assert(strcmp(get_nume(aux13.elems[0]), "Ardelean") == 0);

	Lista aux14 = copy_lista(&aux13);
	assert(dim(&aux14) == 5);
	assert(strcmp(get_nume(aux14.elems[4]), "Ciuntu") == 0);
	assert(strcmp(get_nume(aux14.elems[3]), "Boamba") == 0);
	assert(strcmp(get_nume(aux14.elems[2]), "Boamba") == 0);
	assert(strcmp(get_nume(aux14.elems[1]), "Balaci") == 0);
	assert(strcmp(get_nume(aux14.elems[0]), "Ardelean") == 0);

	assert(comparare(get_elem(&aux13, 3), get_elem(&aux13, 2), 1, 1) == 1);
	assert(comparare(get_elem(&aux13, 3), get_elem(&aux13, 2), 1, 0) == 2);
	assert(comparare(get_elem(&aux13, 3), get_elem(&aux13, 2), 1, 4) == 2);
	assert(comparare(get_elem(&aux13, 0), get_elem(&aux13, 2), 1, 4) == 2);
	assert(comparare(get_elem(&aux12, 0), get_elem(&aux12, 4), 2, 3) == 2);
	assert(comparare(get_elem(&aux13, 3), get_elem(&aux13, 2), 3, 1) == 2);

	destroy_p(&p1);
	destroy_p(&p2);
	destroy_p(&p3);
	destroy(&aux2);	
	destroy(&aux3);
	destroy(&aux4);
	destroy(&aux5);
	destroy(&aux6);
	destroy(&aux7);
	//destroy(&aux8);
	destroy(&aux9);
	destroy(&aux10);
	//destroy(&aux11);
	destroy(&aux12);
	destroy(&aux13);
	destroy(&aux14);
	destroy_serv(&serv);
} 

void test_validator()
{
	//test validator nume, prenume
	char nume[30] = "";
	assert(valid_nume(nume) == 1);
	assert(valid_prenume(nume) == 1);
	strcpy(nume, "ana2sf");
	assert(valid_nume(nume) == 1);
	assert(valid_prenume(nume) == 1);
	strcpy(nume, "ana irina");
	assert(valid_nume(nume) == 1);
	assert(valid_prenume(nume) == 0);
	strcpy(nume, "Ana-Irina");
	assert(valid_prenume(nume) == 0);
	strcpy(nume, "Ana.Irina");
	assert(valid_prenume(nume) == 1);

	//test validator scoruri
	int s[10] = { 1,2,3,4,5,6,7,8,9,10 };
	assert(valid_scor(s) == 0);
	s[5] = 0;
	assert(valid_scor(s) == 0);
	s[7] = -1;
	assert(valid_scor(s) == 1);
	s[7] = 2;
	s[2] = 11;
	assert(valid_scor(s) == 1);

	//test validator participant
	char nume2[30] = "Boamba", prenume[30] = "Emilia-Irina";
	int scoruri[10] = { 1,2,3,4,5,6,7,8,9,10 };
	assert(valid_participant(nume2, prenume, scoruri) == 0);
	strcpy(nume2, "Bo am6ba");
	assert(valid_participant(nume2, prenume, scoruri) == 2);
	strcpy(nume2, "Boamba");
	strcpy(prenume, "EMilia.Irina5");
	assert(valid_participant(nume2, prenume, scoruri) == 3);
	strcpy(prenume, "EMilia Irina");
	scoruri[2] = 20;
	assert(valid_participant(nume2, prenume, scoruri) == 4);
	strcpy(nume2, "Bo am6ba");
	assert(valid_participant(nume2, prenume, scoruri) == 6);
	strcpy(nume2, "Boamba");
	strcpy(prenume, "EMilia.Irina5");
	assert(valid_participant(nume2, prenume, scoruri) == 7);
	strcpy(nume2, "Bo am6ba");
	assert(valid_participant(nume2, prenume, scoruri) == 9);
	scoruri[2] = 2;
	assert(valid_participant(nume2, prenume, scoruri) == 5);
}

void run_all_tests()
{
	test_domain();
	test_repo();
	test_serv();
	test_validator();
}
